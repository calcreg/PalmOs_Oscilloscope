// OscReg.h
// This concerns the menu interface application


// bitmaps

#define bitmapIcon              1000
#define bitmapPalm              1001

// dialogs

#define infoForm                2000
#define infoFormOkButton        2001

#define frmadc16 2012
#define Label001 2112
#define Label002 2113
//#define fld_channel 2110
//#define fld_samples 2111
#define btnstart 1343
#define btnexit 1344
#define btnZ 1349
#define btnZminus 1352
#define btnTplus 1350
#define btnTmin 1351
#define btnOffm 1353
#define btnOffp 1354
#define btnHmin 1355
#define btnHplus 1356
#define btnLdTst 1357
#define btnSndDat 1358
#define btnDsplDat 1359
#define btnDrawAll 1360
#define btnV 1361
#define btnM 1362

#define String001 1348
#define AlertGenericAlert 1345
#define AlertGenericOK 1346
#define check1 2079
#define nodata 2080
#define VersionID 1
#define ApplNameID 1335
#define ApplID 1336

