/* Oscillographe Num�rique
 *    regan 2012
 * This software is licensed for free use, none commercial use.
 * Any part of this shouldn't be used for commercial use.
 */


/* Includes */
#include <PalmOS.h>			// system
#include <PalmCompatibility.h>
#include <SerialMgr.h>
#include <SerialMgrOld.h> 
#include <StdIOPalm.h>
#include "OscReg.h"		// app
//#include <MathLib.h>



#define	ChartRectLeft		30
#define	ChartRectTop		52
#define	ChartRectWidth		100
#define	ChartRectHeight		90
#define MaxDataPoints		ChartRectWidth
#define VertScale			ChartRectHeight / 100

static   Byte   data[100];
static   unsigned char  channels[] = {0X1F, 0X3F,0X5F,0X7F, 0X9F, 0XBF, 0XDF, 0XFF};
static   Boolean		SerIOConnected = false;
static   Boolean        sendmessage(Char * message);

char	*strErrSerSetup = "Error setting up serial port";
char	*strErrSerPortOpen = "Error opening serial port";
char	*strErrRcvChk = "Serial receive check error";
char	*strErrRcvErr = "Serial receive error";
char	*strOKSerClose = "Serial port close OK";
char	*strErrSerClose = "Serial port close error: ";
char	*strErrSerLibOpen = "Error opening serial library";
char	*StrBlank = " ";
	
typedef struct TriggerType {
UInt32 volt; //value of the voltage Same as tableau[]
UInt8 mode; //mode up/down edge none=0 up=1 down=2 
} TriggerType;



	
static void StartApplication(void);
static void StopApplication(void);
static Boolean MainFormHandleEvent(EventPtr event);
static void EventLoop(void);
static void ShowNumResultFld (Word FieldID, ULong val);
static void SerIOOpen(void);
static void SerIOClose(void);
static void SerIOReceive(void);
static void FloatToString(float value, Char *buffer, int Rounding);
static void EnableControl (FormPtr Frm, Word ControlID, Boolean State);
static void EnableField (FormPtr Frm, Word FieldID, Boolean State);
static void AddPoint (Short pt);
static Boolean waitfordata(int NbrTrialToGet);//Modif Regan Many Trails to get data


static void TestVersionSerialMgr(void); // get version
static void TracerGraph(UInt32 *tableau, int NValueToDraw,int Offseti); // impl�mentation regan
static void TracerGraphZoom(UInt32 *tableau, int NValueToDraw,int Offseti); // impl�mentation regan
static void TracerAxis(int centerx,int centery,int width, int height);// implementation regan
static int GererPetitMenu(int Xmenu, int Ymenu);
static void FillTableauTest(UInt32* tableau);// fill table
static void CreateCosinus(float* cosinus);// create approximate good enough cos
static float COS(int i);
static void ZOOM();
static void ZOOMminus();
static void LED(int val);
static int min(int X1, int X2);
static int max(int X1, int X2);
static void TracerAxisZoom(int centerx,int centery,int width, int height);
static void ChgTimeMin();
static void ChgTimePlus();
static void GiveInfo(char* information);
static void Wait(int Time);
static void WriteNbrSamples(int Size);
static void ChgHplus();
static void ChgHmin();
static void ChgOffm();
static void ChgOffp();
static void LoadTest();
static void SendData();
static void SendDisplayData();
static void DrawAll();
static void GivePotential();
static void OpenTheSerialPort();
static void RealTimeMode();

UInt16 SerIORef;

//Dimensionnement Oscillogramme
#define TableSize 2000 // Dimension du tableau de valeur UInt32 des samples
int DrawSize=100; // Quantit� de samples � afficher dans la f�n�tre
#define PoseMenuX 110
#define PoseMenuY 100
#define maxval 255   // Maximum de la valeur de l'octet de conversion ADC0804
#define MaxZoom 10


//Positionnement de l'oscillographe
Int32 HEIGHT=120;
Int32 WIDTH=120;
#define OFFSETX 0
#define ENDLINEY 155
float cosinus[50];
int OffsetGraph=0; //Offset du graph pour le d�placer
int StartGraph = 0;// tracer le graph au d�part une seule fois.
int ZoomX1=0; int ZoomY1=0;
int ZoomX2=0; int ZoomY2=0;
float InfoLed=-1;
UInt32 tableau[TableSize];//Le Graphe des donn�es � afficher
int OrdreZoom=0; //L'ordre du Zoom,. Au premier Zoom l'ordre est 0
RectangleType rP[1];
int Xmin[MaxZoom],Xmax[MaxZoom],Ymin[MaxZoom],Ymax[MaxZoom];//OrdreZoom must be < MaxZoom
int justdidZplus=0, StartApply=0;
int Exiting=0;
int seropenedOnce=0;
UInt32 DeltaTicks=0;
TriggerType Trigger;

int  NbrTrialToGet=20; //Nbr of trials to get the full Tablesize data loaded
int BaudRate = 28800;



/* The port is opened once in SerIOReceive() StartApply =1 after that.
   The serial port is closed after that in the MainPilot() in StopApplication. Therefore
   The serial stays opened while the oscilloscope is running and closes only at the end. 
   This allows synchronisation
*/


static void SendData(){
	int j; char k;
	char tableauByte[TableSize];
	Err 		error;
		
	GiveInfo(" Sending data ..."); 
		//for(j=0;j<100;j++){Test[j]=0xA3;}//On envoie 0xA3 100fois pour tester
		//SerSend(SerIORef, Test, 100, &error);

	for (j=0;j<TableSize;j++){tableauByte[j]=k*tableau[j];} //On envoie les donn�e en m�moire
	SerSend(SerIORef, tableauByte, TableSize, &error);
	GiveInfo(" Data Sent...");
	}			

static void GivePotential(){
	char info[50];
	Int16 pScreenX,pScreenY;
	Boolean pPenDown;
	FormPtr Frm;
	char k; char szResult[50];
	float EY,Y,H,mv,Val;
	int I1,I2;
	int OK,Out;

	OK=0;Out=0;
	GiveInfo("Tap Graph/V ");
	WinDrawLine(WIDTH-10,ENDLINEY,WIDTH-10,ENDLINEY-10);
	WinDrawLine(WIDTH-10,ENDLINEY-10,WIDTH,ENDLINEY-10);

	Loop:	
		while(OK == 0){
			EvtGetPen (&pScreenX,&pScreenY,&pPenDown);

			if (pPenDown == 1) {if ( (WIDTH-pScreenX)*(pScreenY+HEIGHT-ENDLINEY)>0 ){
						Wait(2);
						OK=1;
						}//If we tap in the screen
						if ((WIDTH-pScreenX)<10){
							if (ENDLINEY-pScreenY<10){Out=1;}
						Wait(2);
						}//If we tap in a special place
	
			}//endif pPendown
		}//endwhile ok==0
		GiveInfo("Tap Down Right Corner/Exit ");
		if (Out==1) goto endGivePotential;
		EY=ENDLINEY;Y=pScreenY;H=HEIGHT;mv=maxval;
		Val=500*(EY-Y)/H;
		I1=Val;
		I1=I1/100;
		I2=Val;
		I2=I2-I1*100;
	
		StrPrintF(info, " V=%i.%i ",I1,I2);
		if (pScreenX+38<WIDTH){
			if ((pScreenY-30)<ENDLINEY-HEIGHT){WinDrawChars(info,7,pScreenX+10,pScreenY+20);
			WinDrawLine(pScreenX,pScreenY,pScreenX+10,pScreenY+10);
			}
			else{WinDrawChars(info,7,pScreenX+10,pScreenY-20);
			WinDrawLine(pScreenX,pScreenY,pScreenX+10,pScreenY-10);}
		}
		else{
			if ((pScreenY-30)<ENDLINEY-HEIGHT){WinDrawChars(info,7,pScreenX-30,pScreenY+20);
			WinDrawLine(pScreenX,pScreenY,pScreenX-10,pScreenY+10);
			}
			else{WinDrawChars(info,7,pScreenX-30,pScreenY-20);
			WinDrawLine(pScreenX,pScreenY,pScreenX-10,pScreenY-10);}
		}
		Wait (40);
		OK=0;
		if(Out == 0) goto Loop;

	endGivePotential:
		RctSetRectangle(rP,0,ENDLINEY-HEIGHT-1,WIDTH+1,HEIGHT+1);//Define the erasing rectangle dimensions	
		WinEraseRectangle(rP,0);
		TracerGraph(tableau,DrawSize,OffsetGraph);
	}



static void DrawAll(){RctSetRectangle(rP,0,ENDLINEY-HEIGHT-1,WIDTH+1,HEIGHT+1);//Define the erasing rectangle dimensions	
				WinEraseRectangle(rP,0);
				TracerGraph(tableau,TableSize,0);				}

static void LoadTest(){FillTableauTest(tableau);
				TracerGraph(tableau,DrawSize,OffsetGraph);//tableau,size,offset
				}


static void ChgHplus(){	RctSetRectangle(rP,0,ENDLINEY-HEIGHT-1,WIDTH+1,HEIGHT+1);//Define the erasing rectangle dimensions	
				WinEraseRectangle(rP,0);
				HEIGHT=HEIGHT+10;
				if (HEIGHT>140){WIDTH=WIDTH+10;HEIGHT=HEIGHT-10;}
				TracerGraph(tableau,DrawSize,OffsetGraph);}

static void ChgHmin(){	RctSetRectangle(rP,0,ENDLINEY-HEIGHT-1,WIDTH+1,HEIGHT+1);//Define the erasing rectangle dimensions	
				WinEraseRectangle(rP,0);
				HEIGHT=HEIGHT-10;
				if (HEIGHT<70){WIDTH=WIDTH-10;HEIGHT=HEIGHT+10;}
				TracerGraph(tableau,DrawSize,OffsetGraph);}

static void ChgOffm(){if (OffsetGraph-DrawSize/2>0){OffsetGraph=OffsetGraph-DrawSize/2;}
				else{OffsetGraph=0;}
				RctSetRectangle(rP,0,ENDLINEY-HEIGHT-1,WIDTH+1,HEIGHT+1);//Define the erasing rectangle dimensions	
				WinEraseRectangle(rP,0);
				TracerGraph(tableau,DrawSize,OffsetGraph);}


static void ChgOffp(){if ((OffsetGraph+DrawSize+DrawSize/2)<TableSize){OffsetGraph=OffsetGraph+DrawSize/2;}
				else{OffsetGraph=TableSize-DrawSize;}
				RctSetRectangle(rP,0,ENDLINEY-HEIGHT-1,WIDTH+1,HEIGHT+1);//Define the erasing rectangle dimensions	
				WinEraseRectangle(rP,0);
				TracerGraph(tableau,DrawSize,OffsetGraph);}



static void WriteNbrSamples(int Size){
	UInt32 t;
	char MyString[20];
	RectangleType rP2[1];//To erase the info area
	int x1,y1,x2,y2,k,tim;

	x1=122;y1=130;k=1;
	RctSetRectangle(rP2,x1,y1,40,20);
	WinEraseRectangle(rP2,0);
	StrPrintF(MyString, "%i Sps",Size);//regan test
	WinDrawChars(MyString, StrLen(MyString),x1,y1);
	//Affichage du temps 
	//StrPrintF(MyString, "T=%ims",DeltaTicks*10);
	t=Size;
	t=t*10000; t=t/BaudRate; tim=t;
	StrPrintF(MyString, "T=%ims",tim);
	WinDrawChars(MyString, StrLen(MyString),x1,y1+10);


	}

static void Wait(int Time){
	UInt32 nbrticks,nbrticks2;
	nbrticks=TimGetTicks();
	nbrticks2=nbrticks;
	while (nbrticks2<nbrticks+Time){nbrticks2=TimGetTicks();}
	}


static void ChgTimeMin(){
	FormPtr 	Frm;

	Frm = FrmGetFormPtr(frmadc16);
	EnableControl(Frm, btnTmin, false);//Avoid several interuption without this finished
	if (DrawSize-DrawSize/4>0){DrawSize=DrawSize-DrawSize/4;}
	RctSetRectangle(rP,0,ENDLINEY-HEIGHT-1,WIDTH+1,HEIGHT+1);
	WinEraseRectangle(rP,0);
	TracerGraph(tableau,DrawSize,OffsetGraph);
	}

static void ChgTimePlus(){
	FormPtr 	Frm;

	Frm = FrmGetFormPtr(frmadc16);
	EnableControl(Frm, btnTplus, false);//Avoid several interuption without this finished
	if (DrawSize+DrawSize/4+OffsetGraph<TableSize){DrawSize=DrawSize+DrawSize/4;}
	RctSetRectangle(rP,0,ENDLINEY-HEIGHT-1,WIDTH+1,HEIGHT+1);
	WinEraseRectangle(rP,0);
	TracerGraph(tableau,DrawSize,OffsetGraph);
	}


static int min(int X1, int X2){
	if (X1<X2){return (X1);}
		else {return(X2);}
	}
static int max(int X1, int X2){
	if (X1>X2){return (X1);}
		else {return(X2);}
	}


static void LED(int val){//Toggle "Led" for info
		char informe[10];
		if (val>0) {
			StrPrintF(informe, "[%i]",val);//regan test
			WinDrawChars(informe, StrLen(informe),0,0);}

		if (val==0){
		if (InfoLed==-1){WinDrawChars("[O]",3,0,0);}
		if (InfoLed==1){WinDrawChars("[X]",3,0,0);}
		InfoLed=InfoLed*(-1);
		}
	}

static void GiveInfo(char* information){//Informe by a message at the top
	RectangleType rP2[1];//To erase the info area

	RctSetRectangle(rP2,0,12,124,10);
	WinEraseRectangle(rP2,0);
	WinDrawChars(information, StrLen(information),0,12);
	}


static void SendDisplayData(){//Display hexadecimal Data
	Int16 pScreenX,pScreenY;
	Boolean pPenDown;
	FormPtr Frm;
	int i,OffstY;
	int Offst=0;
	int Out=0; 
	char k; char szResult[50];
	Frm = FrmGetFormPtr(frmadc16);

	EnableControl(Frm, btnDsplDat, false);//Avoid several interuption without this finished
	RctSetRectangle(rP,0,ENDLINEY-HEIGHT-1,WIDTH+1,HEIGHT+1);
	WinEraseRectangle(rP,0);
 	GiveInfo("Tap Area=Display/down=Exit"); 

	while(Out==0){

	EvtGetPen (&pScreenX,&pScreenY,&pPenDown);

	if (pPenDown == 1) {if ( (WIDTH -pScreenX)*(pScreenY+HEIGHT-ENDLINEY)>0 ){
					if( (Offst+HEIGHT/10) < TableSize ){Offst=Offst+10;
											WinEraseRectangle(rP,0);
											}
					}
					if ( (WIDTH-pScreenX)*(pScreenY-140)>0 ){
 						Out=1;
					}//If we tap in a special place
		}//endif pPendown

	OffstY=ENDLINEY-HEIGHT+5;
	if (Offst<ENDLINEY-HEIGHT+5)OffstY=ENDLINEY-HEIGHT+5;
	for (i=Offst;i<(Offst+HEIGHT/10-1);i++){k=tableau[i];
		StrPrintF(szResult, "(0x%x)=%x",i,k);
		WinDrawChars(szResult, StrLen(szResult),20,(i-Offst)*10+OffstY);
		}
	}//EndWhile

	WinEraseRectangle(rP,0);
	TracerGraph(tableau,DrawSize,OffsetGraph);
	}

static void ZOOM(){
	Int16 pScreenX;
	Int16 pScreenY;
	Boolean pPenDown;
	char szResult[50];
	FormPtr 	Frm;
	Int32 i,NewDrawSize,NewOffsetGraph;

	justdidZplus=1;
	Frm = FrmGetFormPtr(frmadc16);
	EnableControl(Frm, btnZ, false);//Avoid several interuption without this finished
	EnableControl(Frm, btnstart, false);


	if (OrdreZoom>=MaxZoom){GiveInfo("Maximum Zoom Reached!!!");goto OutZoom;}

	GiveInfo("---Define-ZoomBox---"); 
	pPenDown=1;
	while (pPenDown==1){EvtGetPen (&pScreenX,&pScreenY,&pPenDown);}
	while (pPenDown==0){EvtGetPen (&pScreenX,&pScreenY,&pPenDown);}

	while (pPenDown==1) {
				EvtGetPen (&pScreenX,&pScreenY,&pPenDown);
				ZoomX1=pScreenX; ZoomY1=pScreenY;
				GiveInfo("--X1,Y1-ok--");
				}

	while (pPenDown==0){EvtGetPen (&pScreenX,&pScreenY,&pPenDown);}


	while (pPenDown==1) {

				EvtGetPen (&pScreenX,&pScreenY,&pPenDown);
				ZoomX2=pScreenX; ZoomY2=pScreenY;
				GiveInfo("--X2,Y2-ok--");
				//StrPrintF(szResult, "X=%i Y=%i",ZoomX2,ZoomY2);//regan test
				//WinDrawChars(szResult, StrLen(szResult),0,30);
				}
	if (ZoomY1<ENDLINEY-HEIGHT){ZoomY1=ENDLINEY-HEIGHT;}
	if (ZoomY2<ENDLINEY-HEIGHT){ZoomY2=ENDLINEY-HEIGHT;}
	if (ZoomX1>WIDTH){ZoomX1=WIDTH;}
	if (ZoomX2>WIDTH){ZoomX2=WIDTH;}

	WinDrawLine(ZoomX1,ZoomY1, ZoomX1,ZoomY2);//Dessiner le carr� du Zoom
	WinDrawLine(ZoomX1,ZoomY1, ZoomX2,ZoomY1);
	WinDrawLine(ZoomX2,ZoomY1, ZoomX2,ZoomY2);
	WinDrawLine(ZoomX1,ZoomY2, ZoomX2,ZoomY2);//
	Wait(30);

	if ((ZoomX1-ZoomX2)*(ZoomY1-ZoomY2)==0){ZoomX1=0;ZoomY1=0;ZoomX2=0;ZoomY2=0;}
	else{	
		Xmin[OrdreZoom]=min(ZoomX1,ZoomX2);Xmax[OrdreZoom]=max(ZoomX1,ZoomX2);
		Ymin[OrdreZoom]=min(ZoomY1,ZoomY2);Ymax[OrdreZoom]=max(ZoomY1,ZoomY2);
		RctSetRectangle(rP,0,ENDLINEY-HEIGHT-1,WIDTH+1,HEIGHT+1);
		WinEraseRectangle(rP,0);

		//Calculation for The size in X to draw
		NewDrawSize=DrawSize;NewOffsetGraph=OffsetGraph;
		if (OrdreZoom>0){
			for (i=0;i<OrdreZoom;i++){NewDrawSize = NewDrawSize*(Xmax[i]-Xmin[i])/WIDTH;
			NewOffsetGraph=NewOffsetGraph+Xmin[i]*NewDrawSize/WIDTH;
			}
		}
		TracerGraphZoom(tableau, NewDrawSize*(Xmax[OrdreZoom]-Xmin[OrdreZoom])/WIDTH,NewOffsetGraph+Xmin[OrdreZoom]*NewDrawSize/WIDTH);	
		OrdreZoom++;		}
	OutZoom:
	}



static void ZOOMminus(){
	char szResult[50];
	FormPtr 	Frm;
	Int32 i,NewDrawSize,NewOffsetGraph;
	justdidZplus=0;
	//for convenience OrdreZoom has to be decreased then at the increased
	// Because at the interuption it is decreased also


	Frm = FrmGetFormPtr(frmadc16);
	EnableControl(Frm, btnZminus, false);//Avoid several interuption without this finished

		RctSetRectangle(rP,0,ENDLINEY-HEIGHT-1,WIDTH+1,HEIGHT+1);
		WinEraseRectangle(rP,0);

		//Calculation for The size in X to draw
		NewDrawSize=DrawSize;NewOffsetGraph=OffsetGraph;
		if (OrdreZoom>0){
			for (i=0;i<OrdreZoom;i++){NewDrawSize = NewDrawSize*(Xmax[i]-Xmin[i])/WIDTH;
			NewOffsetGraph=NewOffsetGraph+Xmin[i]*NewDrawSize/WIDTH;
			}
		}
		LED(OrdreZoom);
		TracerGraphZoom(tableau, NewDrawSize*(Xmax[OrdreZoom]-Xmin[OrdreZoom])/WIDTH,NewOffsetGraph+Xmin[OrdreZoom]*NewDrawSize/WIDTH);
	
		WinDrawLine(Xmin[OrdreZoom+1],Ymin[OrdreZoom+1], Xmax[OrdreZoom+1],Ymin[OrdreZoom+1]);//Draw previous Zoom Square
		WinDrawLine(Xmin[OrdreZoom+1],Ymax[OrdreZoom+1], Xmax[OrdreZoom+1],Ymax[OrdreZoom+1]);//for rememberance
		WinDrawLine(Xmin[OrdreZoom+1],Ymin[OrdreZoom+1], Xmin[OrdreZoom+1],Ymax[OrdreZoom+1]);//Draw previous Zoom Square
		WinDrawLine(Xmax[OrdreZoom+1],Ymin[OrdreZoom+1], Xmax[OrdreZoom+1],Ymax[OrdreZoom+1]);//for rememberance
	
	}


static void TracerAxisZoom(int centerx,int centery,int width, int height){
	WinDrawLine(centerx-width/2,centery-height/2, centerx+width/2, centery-height/2);	
	WinDrawLine(centerx-width/2,centery+height/2, centerx+width/2, centery+height/2);	
	WinDrawLine(centerx+width/2,centery-height/2,centerx+width/2,centery+height/2);
}


static void TracerGraphZoom(UInt32 *table, int NValueToDraw,int Offseti){
	int height = HEIGHT ;
	Int32 width = WIDTH;
	Int32 i,j;
	Int16 X1,Y1,X2,Y2;
	Int16 offsetX=OFFSETX;
	Int16 endlineY=ENDLINEY;
	char info[10];
	UChar Y;

	TracerAxisZoom(offsetX+width/2,endlineY-height/2,width,height);
	Y=table[Offseti];
	Y1 = endlineY-Y*height/maxval;
	//Y1 =endlineY-(Ymax-Y1)*height/(Ymax-Ymin);
		if (OrdreZoom>0){
			for (j=0;j<OrdreZoom;j++){
				Y1=endlineY-(Ymax[j]-Y1)*height/(Ymax[j]-Ymin[j]);
			}
		}
		Y1=endlineY-(Ymax[OrdreZoom]-Y1)*height/(Ymax[OrdreZoom]-Ymin[OrdreZoom]);
		if (Y1<ENDLINEY-HEIGHT){Y1=ENDLINEY-HEIGHT;}//Pas de d�bordement
		if (Y1>ENDLINEY) {Y1=ENDLINEY;}



	for (i=0;i<(NValueToDraw-1);i++){
		X2=(i+1)*width/NValueToDraw;
		X1=i*width/NValueToDraw;
		Y=table[i+1+Offseti];
		Y2=endlineY-Y*height/maxval;
		if (OrdreZoom>0){
			for (j=0;j<OrdreZoom;j++){
				Y2=endlineY-(Ymax[j]-Y2)*height/(Ymax[j]-Ymin[j]);
			}
		}
		Y2=endlineY-(Ymax[OrdreZoom]-Y2)*height/(Ymax[OrdreZoom]-Ymin[OrdreZoom]);


		if (Y2<ENDLINEY-HEIGHT){Y2=ENDLINEY-HEIGHT;}//Pas de d�bordement
		if (Y2>ENDLINEY) {Y2=ENDLINEY;}
		WinDrawLine(X1,Y1,X2,Y2);
		Y1=Y2;X1=X2;
		}
		StrPrintF(info, "-- Zoom n�%i display --",OrdreZoom+1);
		WinDrawChars(info,StrLen(info),0,12);
		WriteNbrSamples(NValueToDraw); 
	}


static void TracerAxis(int centerx,int centery,int width, int height){
	float XS,XS2;
	float TS,w,DS,Of;
	int X1,X2;

	//IndexedColorType WinSetForeColor(IndexedColorType foreColor)
	//typedef struct RGBColorType {
	//UInt8 index;
	//UInt8 r;
	//UInt8 g;
	//UInt8 b;
	//} RGBColorType;

	//void WinSetForeColorRGB(const RGBColorType *newRgbP,RGBColorType *prevRgbP)


	RGBColorType MyPenColor,OldPenColor,OldPenColor2;

	MyPenColor.r = 0xE7;//red Only
	MyPenColor.g = 0x0A; 
	MyPenColor.b = 0x0A;
	
	WinSetForeColorRGB(&MyPenColor,&OldPenColor);
	

	TS=TableSize;// Castings to go to floating value
	w=width;
	DS=DrawSize;
	Of=OffsetGraph;
	
	//We must do the calculation with floating point otherwise it doesn't work.
	XS=centerx-w/2+Of*w/TS;
	XS2=XS+DS*w/TS;

	X1=XS;
	X2=XS2;
	WinDrawLine(X1,centery-height/2-1,X2,centery-height/2-1);

	MyPenColor.r = 0x0A;
	MyPenColor.g = 0xE7; //Green Only
	MyPenColor.b = 0x0A;
	
	WinSetForeColorRGB(&MyPenColor,&OldPenColor2);


	WinDrawLine(centerx+width/2,centery-height/2,centerx+width/2,centery+height/2);


	WinDrawLine(centerx-width/2,centery,centerx+width/2,centery);
	WinDrawLine(centerx,centery-height/2, centerx, centery+height/2);	

	WinDrawLine(centerx-width/2,centery-height/2, centerx+width/2, centery-height/2);	
	WinDrawLine(centerx-width/2,centery+height/2, centerx+width/2, centery+height/2);	

	WinDrawLine(centerx-2,centery-height/10,centerx+2,centery-height/10);
	WinDrawLine(centerx-2,centery-2*height/10,centerx+2,centery-2*height/10);
	WinDrawLine(centerx-2,centery-3*height/10,centerx+2,centery-3*height/10);
	WinDrawLine(centerx-2,centery-4*height/10,centerx+2,centery-4*height/10);
	
	WinDrawLine(centerx-2,centery+height/10,centerx+2,centery+height/10);
	WinDrawLine(centerx-2,centery+2*height/10,centerx+2,centery+2*height/10);
	WinDrawLine(centerx-2,centery+3*height/10,centerx+2,centery+3*height/10);
	WinDrawLine(centerx-2,centery+4*height/10,centerx+2,centery+4*height/10);

	WinDrawLine(centerx-width/10,centery+2, centerx-width/10, centery-2);	
	WinDrawLine(centerx-2*width/10,centery+2, centerx-2*width/10, centery-2);	
	WinDrawLine(centerx-3*width/10,centery+2, centerx-3*width/10, centery-2);	
	WinDrawLine(centerx-4*width/10,centery+2, centerx-4*width/10, centery-2);	

	WinDrawLine(centerx+width/10,centery+2, centerx+width/10, centery-2);	
	WinDrawLine(centerx+2*width/10,centery+2, centerx+2*width/10, centery-2);	
	WinDrawLine(centerx+3*width/10,centery+2, centerx+3*width/10, centery-2);	
	WinDrawLine(centerx+4*width/10,centery+2, centerx+4*width/10, centery-2);	

	WinSetForeColorRGB(&OldPenColor,&OldPenColor2); //Set OldColor
	}


static int GererPetitMenu(int Xmenu, int Ymenu){
	Int16 pScreenX;
	Int16 pScreenY;
	Boolean pPenDown;
	int littlemenu;

	EvtGetPen (&pScreenX,&pScreenY,&pPenDown);
	littlemenu=0;
	if (pPenDown == 1) {

		if(pScreenX < WIDTH && pScreenY>(ENDLINEY-HEIGHT) ) littlemenu=1;

		if((pScreenX - (Xmenu+25))*(pScreenX - (Xmenu+25)) < 2500 ){
			if((pScreenY - (Ymenu+5))*(pScreenY - (Ymenu+5)) < 25 ){littlemenu=2;}}

		if((pScreenX - (Xmenu+25))*(pScreenX - (Xmenu+25)) < 2500 ){
			if((pScreenY - (Ymenu+15))*(pScreenY - (Ymenu+15)) < 25 ){littlemenu=3;}}

		if((pScreenX - (Xmenu+25))*(pScreenX - (Xmenu+25)) < 2500 ){
			if((pScreenY - (Ymenu+25))*(pScreenY - (Ymenu+25)) < 25 ){littlemenu=4;}}

		}
	return(littlemenu);
	}


static void TracerGraph(UInt32 *table, int NValueToDraw,int Offseti){
	int height = HEIGHT ;
	Int32 width = WIDTH;//Int32 instead of int because of great number in intermediate calculation
	Int32 i;
	Int16 X1;
	Int16 Y1;
	Int16 X2;
	Int16 Y2;
	Int16 offsetX=OFFSETX;
	Int16 endlineY=ENDLINEY;
	UChar Y;
	OrdreZoom=0; //Initialise OrdreZoom


	TracerAxis(offsetX+width/2,endlineY-height/2,width,height);
	Y=table[Offseti];
	Y1 = endlineY-Y*height/maxval;

		for (i=0;i<NValueToDraw-1;i++){
		X2=(i+1)*width/NValueToDraw;
		X1=i*width/NValueToDraw;
		Y=table[i+1+Offseti];
		Y2=endlineY-Y*height/maxval;
	if (Y2<ENDLINEY-HEIGHT){Y2=ENDLINEY-HEIGHT;}//Pas de d�bordement
	if (Y2>ENDLINEY) {Y2=ENDLINEY;}
		WinDrawLine(X1,Y1,X2,Y2);
		Y1=Y2;X1=X2;
		}
		GiveInfo("--- Display Mode 0 ---"); 
		WriteNbrSamples(NValueToDraw); 
	}

static void FillTableauTest(UInt32* table){ // Creation de la fonction cosinus^2*255
	int i; int N=TableSize; float k;
	for (i=0;i<N;i++){k=i;table[i]=COS(i)/(k/100+1);}
	}

static float COS(int a){
	float val;
	if (a<50) {val=cosinus[a];}
	while (a>=50){
			a=a-50;
			if(a<50){val=cosinus[a];}//50 =taille du tableau cosinus
		}
	return(val);
	}

static void CreateCosinus(float* cosin){ // Creation de la fonction cosinus^2*255
	int i; int N=50; float var;
	float k=0;int j;
	for (i=0;i<N/2;i++){k=k+3.1415927/N;
				var=(1-k*k/2+k*k*k*k/24-k*k*k*k*k*k/720+k*k*k*k*k*k*k*k/40320+k*k*k*k*k*k*k*k*k*k/3628800);
				cosin[i]= var*var*maxval;// cos^2*255
				//cosin[i] = (1+var)*maxval/2;// (1+cos)*255			
				}
	j=N/2;
	for (i=N/2;i<N;i++){cosin[i]=cosin[j];j=j-1;}
	}

	



//------------------------------------------------
static void OpenTheSerialPort(){
	SerSettingsType sstSetup;
	FormPtr 	Frm, frmP;
	FieldPtr	fptr;
	Err 		error;
	Err		Error;
	int BaudMenuX=10;
	int BaudMenuY=60;
	int menu;
	

	Frm = FrmGetFormPtr(frmadc16);

	EnableControl(Frm, btnexit, true);
	EnableControl(Frm, btnstart, false);

	RctSetRectangle(rP,0,ENDLINEY-HEIGHT+1,WIDTH+1,HEIGHT+1);//Define the erasing rectangle dimensions	
	WinEraseRectangle(rP,0);

	/* We must select the speed for the Serial port */
	GiveInfo("Select BaudRate Speed");
 
	WinDrawChars("115200 Bauds",12,BaudMenuX+5,BaudMenuY);
	WinDrawChars(" 57600 Bauds",12,BaudMenuX+5,BaudMenuY+10);
	WinDrawChars(" 28800 Bauds",12,BaudMenuX+5,BaudMenuY+20);

	WinDrawChars("You use this program   ",23,5,BaudMenuY+38);
	WinDrawChars("at your own risk.      ",23,5,BaudMenuY+48);

	WinDrawChars("OscReg Soft V1.0 coded ",23,5,BaudMenuY+58);
	WinDrawChars(" in 2012  by Regan B.S. ",23,5,BaudMenuY+68);
	WinDrawChars(" www.palmreg.fr.mu ",18,10,BaudMenuY+84);

	menu=0;
	while(menu<2){
		menu=GererPetitMenu(BaudMenuX, BaudMenuY);
		}//endwhile
	if (menu==2){WinDrawChars("115200 Bauds <---",17,BaudMenuX+5,BaudMenuY);BaudRate=115200;}
	if (menu==3){WinDrawChars(" 57600 Bauds <---",17,BaudMenuX+5,BaudMenuY+10);BaudRate= 57600;}
	if (menu==4){WinDrawChars(" 28800 Bauds <---",17,BaudMenuX+5,BaudMenuY+20);BaudRate= 28800;}
	if (menu>4){GiveInfo("Error:BaudRate=115200");}
	Wait(30);



	/* Open the Serial library , then the Serial Port */
	Error = SysLibFind("Serial Library", &SerIORef);
	if (Error) {
		FrmCustomAlert (AlertGenericAlert, strErrSerLibOpen, "can't open library","can't open library" );
		SerClearErr(SerIORef);
		return;		
	}

	error = SerOpen(SerIORef, 0,BaudRate);
	if (error) {
		FrmCustomAlert (AlertGenericAlert, strErrSerPortOpen, "can't open port","can't open port" );
		SerClearErr(SerIORef);
		return;
	}	
	
	
   SerIOConnected = true;	
	sstSetup.baudRate = BaudRate;
	//sstSetup.flags = serSettingsFlagBitsPerChar8|
	//			        serSettingsFlagParityOnM;		
	sstSetup.flags = serSettingsFlagBitsPerChar8;	//

	}

static void RealTimeMode(){
	char info[50];
	Int16 pScreenX,pScreenY;
	Boolean pPenDown;
	FormPtr Frm;
	char k;
	int OK,Out;
	float EY,Y,H,mv,Val;
	int i;
	RGBColorType MyPenColor,OldPenColor,OldPenColor2;
	float I1,I2,I3;

	OK=0;Out=0;

	//if (StartApply==0) {goto EndRealTimeMode;}

	RctSetRectangle(rP,0,ENDLINEY-HEIGHT-1,WIDTH+1,HEIGHT+1);
	GiveInfo("--- Running Mode ---");
	WinDrawLine(WIDTH-10,ENDLINEY,WIDTH-10,ENDLINEY-10);
	WinDrawLine(WIDTH-10,ENDLINEY-10,WIDTH,ENDLINEY-10);



	while(Out == 0){
		EvtGetPen (&pScreenX,&pScreenY,&pPenDown);

		if (pPenDown == 1) {
			if ( (WIDTH-pScreenX)*(pScreenY+HEIGHT-ENDLINEY)>0 ){
					Wait(2);
					OK=1;
					if ((WIDTH-pScreenX)<10){
						if (ENDLINEY-pScreenY<10){Out=1;goto EndRunningMode;}
						}//If we tap in a special place

					/* Tap on the screen to set the trigger level */
					/* Tap on the left: rising edge               */
					/*Tap on the right: falling edge              */
					
					EY=ENDLINEY;Y=pScreenY;H=HEIGHT;mv=maxval;
					Val=500*(EY-Y)/H; // 100 * the real voltage
					Trigger.volt=Val;
					

					if (pScreenX<WIDTH/2){Trigger.mode=2;}
					else {Trigger.mode=1;}

					MyPenColor.r = 0xE7;//red Only
					MyPenColor.g = 0x0A; 
					MyPenColor.b = 0x0A;
	
					WinSetForeColorRGB(&MyPenColor,&OldPenColor);
					if (Trigger.mode==1) {
						GiveInfo(" Trigger UP ");
						WinDrawLine(WIDTH/2,pScreenY,WIDTH,pScreenY);
						WinDrawLine(WIDTH/2,pScreenY+10,WIDTH/2,pScreenY);
						WinDrawLine(WIDTH/4,pScreenY+10,WIDTH/2,pScreenY+10);
						}
					if (Trigger.mode==2){
						GiveInfo(" Trigger DOWN ");
						WinDrawLine(0,pScreenY,WIDTH/2,pScreenY);
						WinDrawLine(WIDTH/2,pScreenY+10,WIDTH/2,pScreenY);
						WinDrawLine(WIDTH/2,pScreenY+10,3*WIDTH/4,pScreenY+10);
						}

					WinSetForeColorRGB(&OldPenColor,&OldPenColor2);
					Wait(10);

					}//If we tap in the screen	
		}//endif pPendown
		if (!waitfordata(NbrTrialToGet)){
				GiveInfo("Acquisition Data problem");
				Wait(20);
				GiveInfo("--- Running Mode ---");
			}
		else{
				for (i=0;i<TableSize-DrawSize-1;i++){//tableau take values between 0 and 255
				I1=500*tableau[i]/255;I2=500*tableau[i+1]/255;
				I3=Trigger.volt;	//Trigger.volt takes value between 0 and 500
				  if ( (I1-I3)*(I2-I3) < 0 ){
					if (Trigger.mode==1) {if (tableau[i+1]>tableau[i]){
										OffsetGraph=i; goto EndSearchOffset;
									}
					}
					if (Trigger.mode==2) {if (tableau[i+1]<tableau[i]){
										OffsetGraph=i; goto EndSearchOffset;
									}
					}
				  }
				}//end for i
			EndSearchOffset:
				WinEraseRectangle(rP,0);
				TracerGraph(tableau,DrawSize,OffsetGraph);
				WinDrawLine(WIDTH-10,ENDLINEY,WIDTH-10,ENDLINEY-10);//DrawLittleSquare
				WinDrawLine(WIDTH-10,ENDLINEY-10,WIDTH,ENDLINEY-10);
				WinDrawLine(0,ENDLINEY-Trigger.volt*HEIGHT/500,3,ENDLINEY-Trigger.volt*HEIGHT/500);
				GiveInfo("--- Running Mode ---");
				//Wait(10);
		}

	} //endwhile ok==0

	EndRunningMode:
		RctSetRectangle(rP,0,ENDLINEY-HEIGHT-1,WIDTH+1,HEIGHT+1);
		WinEraseRectangle(rP,0);
		TracerGraph(tableau,DrawSize,OffsetGraph);
	}




static void SerIOReceive(void) {
	ULong		RcvCount = 0;
	Byte    msg;
   	char szvolts[6],szResult[50], limit[3] ;
	UInt i, value;
	float volts;
	char Test[100];
	UInt32 j;
	FormPtr 	Frm, frmP;

	// Definition regan --------------------------------

      Int16 pScreenX;
	Int16 pScreenY;
	Boolean pPenDown;
	int littlemenu;


	//                ------------------------------------

	Frm = FrmGetFormPtr(frmadc16);

	EnableControl(Frm, btnexit, true);
	EnableControl(Frm, btnstart, false);

	RctSetRectangle(rP,0,ENDLINEY-HEIGHT-1,WIDTH+1,HEIGHT+1);//Define the erasing rectangle dimensions	


//	if(seropenedOnce==1) goto AlreadyOpened;
//	seropenedOnce=1;
		

	AlreadyOpened:

	
	//for (i=0; i < 1; i++) // Regan: Chang� au lieu de 2 fois faire la boucle
	//{
	
	//msg = channels[0];
	msg=0;
	littlemenu=0;	
	//littlemenu = GererPetitMenu(PoseMenuX,PoseMenuY);
	if (StartGraph==0){
				CreateCosinus(cosinus);
				//FillTableauTest(tableau);
				for (j=0;j<TableSize;j++){tableau[j]=0;}
				WinEraseRectangle(rP,0);
				TracerGraph(tableau,DrawSize,0);//tableau,size,offset
				StartGraph=1;
				}

	if (StartApply==0) goto EndReceive;
	if (Exiting==1){goto EndReceive;waitfordata(1);}

   if (!waitfordata(NbrTrialToGet)){//the acquisition is here
		GiveInfo("Acquisition Data problem");
   //FrmCustomAlert(nodata,"reveive","error receiving","error receiving" );
   }
 	else{
		WinEraseRectangle(rP,0);
		TracerGraph(tableau,DrawSize,OffsetGraph);
	}


     
    //TestVersionSerialMgr();

	EndReceive:

 //}end for

//StopApplication();	
}



static void TestVersionSerialMgr(void){         // impl�mentation
/*	Err error;
	UInt32 value; UInt16 val;UInt32 RomVersion; WChar* AddValRom;
      char ValueStr[50] ;

	error = FtrGet(sysFileCSerialMgr,sysFtrNewSerialVersion,&value);
      val = value; // il s'agit en fait d'un cast UInt32 vers UInt16 pour StrPrintF
      StrPrintF(ValueStr, "SerialMgrValue=%d",val);//only  %d, %i, %u, %x, %s, %x
      WinDrawChars(ValueStr, StrLen(ValueStr),0,100);

	error = FtrGet(sysFtrCreator,sysFtrNumROMVersion,&RomVersion);
	AddValRom=&RomVersion;
	//RomVersion = 0x12345678;
	StrPrintF(ValueStr, "RomVersion=%x%x",AddValRom[0],AddValRom[1]);//only  %d, %i, %u, %x, %s
      WinDrawChars(ValueStr, StrLen(ValueStr),0,110);
*/          
}




//--------------------------------------------------------------

 static void ShowNumResultFld (Word FieldID, ULong val) {
	FormPtr 	Frm;
	FieldPtr 	FldPtr;
	char		Buf[10];
	
	Frm = FrmGetFormPtr(frmadc16);
	FldPtr = (FieldPtr)(FrmGetObjectPtr(Frm, (FrmGetObjectIndex(Frm, FieldID))));
	StrIToA(Buf, val);
	FldDelete(FldPtr, 0, FldGetTextLength(FldPtr));
	FldInsert(FldPtr, Buf, StrLen(Buf));
}
 
static void EnableControl (FormPtr Frm, Word ControlID, Boolean State) {
	ControlPtr 	cptr;
	
	cptr = (ControlPtr)(FrmGetObjectPtr(Frm, (FrmGetObjectIndex(Frm, ControlID))));
	if (State)
		CtlShowControl(cptr);
	else
		CtlShowControl(cptr);
}


/*
 * EnableField
 */
static void EnableField (FormPtr Frm, Word FieldID, Boolean State) {
	FieldPtr	fptr;
	fptr = (FieldPtr)(FrmGetObjectPtr(Frm, (FrmGetObjectIndex(Frm,FieldID))));
	if (State)
		FldDrawField(fptr);
	else
		FldEraseField(fptr);
}


/*
 * SerIOOpen
 */
static void SerIOOpen(void) {
	Err		Error;
	FormPtr 	Frm;
	FieldPtr	fptr;
	Frm = FrmGetFormPtr(frmadc16);

	EnableControl(Frm, btnexit, true);
	EnableControl(Frm, btnstart, false);


}


/*
 * SerIOClose
 */
static void SerIOClose(void) {
	char		BufSmall[17];
	char		BufLarge[80];
	Err			Error;
	
	if (!SerIOConnected)
		return;
		
	Error = SerClose (SerIORef);
	if (Error) {
		StrIToA(BufSmall, Error);
		StrCopy(BufLarge, strErrSerClose);
		StrCat(BufLarge, BufSmall);
	}
}


/*
 * StopApplication
 */
static void StopApplication(void) {
	FormPtr 	Frm;
	FieldPtr	fptr;
	Frm = FrmGetFormPtr(frmadc16);
	
	SerIOClose();
	EnableControl(Frm, btnstart, true);
}


/*
 * MainFormHandleEvent
 */
static Boolean MainFormHandleEvent(EventPtr event) {
	Boolean	handled = false;
	EventType	newEvent;
	
	if (event->eType == ctlSelectEvent) {
		switch (event->data.ctlEnter.controlID) {
			case btnexit:
				GiveInfo("Wait while Quiting...");
 			   	MemSet(&newEvent, sizeof(EventType), 0);
			   	newEvent.eType = appStopEvent;
			   	EvtAddEventToQueue(&newEvent);
				Exiting=1;
  				break;


   			case btnstart:	
				if (StartApply==0){
					StartApply=1;
					OpenTheSerialPort();
					} 
				SerIOReceive();
   				break;

			case btnZ:
				ZOOM();
				break;

			case btnZminus:
				OrdreZoom--;
				LED(OrdreZoom);
				if (OrdreZoom<=0){
					RctSetRectangle(rP,0,ENDLINEY-HEIGHT-1,WIDTH+1,HEIGHT+1);
					WinEraseRectangle(rP,0);
					TracerGraph(tableau,DrawSize,OffsetGraph);
					}
				if (OrdreZoom>0){
					if (justdidZplus==1){OrdreZoom=OrdreZoom-1;}
					ZOOMminus();
					}
				break;

			case btnTmin:
				ChgTimeMin();
				break;

			case btnTplus:
				ChgTimePlus();
				break;

			case btnHplus:
				ChgHplus();
				break;

			case btnHmin:
				ChgHmin();
				break;

			case btnOffm:
				ChgOffm();
				break;

			case btnOffp:
				ChgOffp();
				break;

			case btnLdTst:
				LoadTest();
				break;
			case btnSndDat:
				SendData();
				break;

			case btnDsplDat:
				SendDisplayData();
				break;
			case btnDrawAll:
				DrawAll();
				break;

			case btnV:
				GivePotential();
				break;

			case btnM: // Mode
				RealTimeMode();
				break;



   		}
		handled = true;
	}

	else if (event->eType == nilEvent) {
		//In case of no event for example click on screen or something else but no event.
		handled = true;
	}
		
	return handled;
}


/*
 * EventLoop
 */
static void EventLoop(void) {
	EventType	event;
	//Word		error;
	
	do {
		EvtGetEvent(&event, evtWaitForever);
		if (! SysHandleEvent(&event))
				if (! MainFormHandleEvent(&event))
					FrmHandleEvent(FrmGetActiveForm(), &event);

		//if (StartApply==1) SerIOReceive();//Faire un aller � chaque tour 
	}
	while (event.eType != appStopEvent);
}


/*
 * StartApplication
 */
static void StartApplication(void) {
	Err			Error;
	FormPtr		Frm;

	// Initialize and draw the main form.
	Frm = FrmInitForm(frmadc16);	
	FrmSetActiveForm(Frm);
	FrmDrawForm(Frm);

	EnableControl(Frm, btnexit, true);

	//Error = SysLibFind("Serial Library", &SerIORef);
	//if (Error) {
	//	FrmCustomAlert (AlertGenericAlert, strErrSerLibOpen, "can't open library","can't open library" );
	//	SerClearErr(SerIORef);
	//	return;		
	//}
}

static   Boolean  waitfordata(int NbrTrialToGet){
Boolean ret;
ULong nbytes=3;
Byte anbytes;
Err err;
int i;
UChar tableauByte[TableSize];
UInt32 nbrticks,nbrticks2;


for (i=0;i<TableSize;i++){tableauByte[i]=0;}
//SerReceiveWait(SerIORef, 3, 10);  // Regan: Chang� de 1000 � 10 timout
//SerReceiveCheck(SerIORef, &nbytes);//Checks the receive FIFO and returns the number of bytes in the serial receive queue
//anbytes = SerReceive(SerIORef, data, nbytes, 100, &err);

	for (i=0;i<NbrTrialToGet;i++){
	nbrticks=TimGetTicks();
	anbytes = SerReceive(SerIORef, tableauByte,TableSize, 20, &err);//Wait 20 max for the timeout between bytes
	nbrticks2=TimGetTicks();
	DeltaTicks=nbrticks2-nbrticks;
	if (err ==0) {goto OutFor;}// got one set without error => out
	SerReceiveFlush(SerIORef, 0);//Flush remaining data.
	}

OutFor:
	for (i=0;i<TableSize;i++){tableau[i]=tableauByte[i];}

if (err != 0)
ret = false;
   
else
ret = true;
SerReceiveFlush(SerIORef, 0);//Put to 0 otherwise it waits

//ret=false;//modif regan //Ne pas g�n�rer d'erreur intempestive
return(ret);
}


void FloatToString(float value, Char *buffer, int Rounding)
{
long iValue;
float dDecimal;
long iDecValue;
int i;
char sResult[50];
char sDecimal[50];
char sTemp[50];
 
// Get integer and decimal portions
iValue = value;
dDecimal = value - iValue;
if (dDecimal < 0.000000001)
  dDecimal = 0;
 
// Convert integer portion to string
StrIToA(sResult, iValue);
if (StrLen(sResult) < 1)
  StrCopy(sResult, "0");
StrCat(sResult, ".");
 
// Round decimal portion
for (i = 1; i <= Rounding; i++)
  dDecimal = dDecimal * 10;
 
iDecValue = dDecimal;
if (dDecimal - iDecValue >= 0.5)
  iDecValue++;
 
// Add decimal portion
StrIToA(sDecimal, iDecValue);
 
// Add leading zeros if neccessary
if (StrLen(sDecimal) < Rounding)
  for (i = 1; i <= Rounding - StrLen(sDecimal); i++)
  StrCat(sResult, "0");
StrCat(sResult, sDecimal);
 
// Copy into return string
StrCopy(buffer, sResult);
 
return;
}
 

/*
 * PilotMain
 */
DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags) {
	if (cmd == sysAppLaunchCmdNormalLaunch)	{

		Trigger.mode = 0; // Initialize to trigger None.
		StartApplication();
		EventLoop();
		StopApplication();
	}
	return 0;
}

